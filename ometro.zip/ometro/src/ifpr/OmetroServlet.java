package ifpr;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.swing.*;
import java.io.IOException;
import java.io.PrintWriter;

//url do arquivo
@WebServlet("/calcular")
public class OmetroServlet extends HttpServlet {
    //permite métodos de requisição
    @Override
    protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

        Integer porcentagem = 0;
        Integer porcentagem2 = 0;

        Integer resultado = 0;

        String nome = req.getParameter("nome");
        String nome2 = req.getParameter("nome2");

        for (Character c : nome.toCharArray() ) {
            porcentagem += (int) c;
        }

        for (Character c : nome2.toCharArray() ) {
            porcentagem2 += (int) c;
        }

        Integer aleatorio = Integer.valueOf((int) (Math.random() * 100)) ;
        resultado = (porcentagem % 100) - (porcentagem2 % aleatorio);


        //imprime no console
        //System.out.println("Entrou na Servlet");
        //imprime no navegador
        //PrintWriter out = resp.getWriter();
        //out.println("xxxxx"+nome+idade);

        //
        req.setAttribute("r", resultado);
        //req.setAttribute("i", idade);
        RequestDispatcher dispatcher = req.getRequestDispatcher("resposta.jsp");
        dispatcher.forward(req, resp);

    }
}
